package com.example.a3rtubler1;

public class MemberTumbler {

    private String tumblerid;


    public MemberTumbler(String tumblerid){
        this.tumblerid = tumblerid;
    }

    public String getTumblerid(){ return  this.tumblerid; }
    public void setTumblerid(String tumblerid){
        this.tumblerid = tumblerid;
    }

}