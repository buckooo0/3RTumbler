package com.example.a3rtubler1;

public interface Listener {

    void onDialogDisplayed();

    void onDialogDismissed();
}
