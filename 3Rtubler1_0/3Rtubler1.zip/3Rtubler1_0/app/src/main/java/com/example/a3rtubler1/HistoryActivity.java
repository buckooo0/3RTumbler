package com.example.a3rtubler1;

import android.nfc.FormatException;
import android.nfc.NdefMessage;
import android.os.Bundle;
import android.util.Log;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.IOException;

public class HistoryActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private int myRank;
    private TextView historyView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        mAuth = FirebaseAuth.getInstance();
        historyView = findViewById(R.id.my_history);

        setHistory();
    }

    private void setHistory() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        // Access a Cloud Firestore instance from your Activity
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        String docid = ((MemberInfoInit)MemberInfoInit.context).docId;
        final String[] tumbid = new String[1];

        DocumentReference docRef = db.collection("users").document(docid);

        docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        tumbid[0] = document.getData().get("tumblerid").toString();
                        String value = document.get("paycount").toString();
                        String message = "paycount: " + value;

                        message = translateCount(Integer.parseInt(value));
                        historyView.setText(message);
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "Search Failed", Toast.LENGTH_SHORT);
                }
            }
        });
/*
        CollectionReference userRef = db.collection("users");
        Query totalRank = userRef.orderBy("paycount");
        totalRank.get().addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                int index = 1;
                for (DocumentSnapshot ds: queryDocumentSnapshots.getDocuments()) {
                    if (ds.getString("tumblerid").toString() == tumbid[0]) {
                        myRank = index;
                    }
                    index++;
                }
            }
        });
*/
    }

    private String translateCount(int value) {
        int co2 = value * 52;
        float tree = co2 / 60000;

        String message = "\n결제횟수 " + value + "회\n" + "\n절약한 이산화탄소 "  + co2 + "g\n" + "\n나무 " + tree + "그루를 심은 효과\n";
        return message;
    }
}

